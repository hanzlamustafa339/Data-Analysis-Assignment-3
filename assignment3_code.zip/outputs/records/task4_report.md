# Hybrid pipeline report - unseen test split

**Images:** 12 | **Passed:** 11 | **Flagged:** 1

---

## test_000 - OK

- measured objects: 8 (ground truth 8, regime sparse)
- U-Net Dice: 0.9374
- count matches measurement: True

The segmentation mask for image test_000 revealed a moderate density of objects, with a mean area of 208 pixels. The objects exhibited a range of sizes, from 72 to 452 pixels, and had a mean eccentricity of 0.62 and mean solidity of 0.92. The object intensity was relatively low, at a mean value of 0.21. Overall, the quality of the segmentation was deemed satisfactory.

## test_001 - OK

- measured objects: 14 (ground truth 19, regime normal)
- U-Net Dice: 0.9334
- count matches measurement: True

The segmentation mask for test_001 revealed a moderate density of objects, with a mean area of 218 pixels. The objects exhibited a range of sizes, from 64 to 660 pixels. The mean eccentricity and solidity values suggest a generally well-defined shape for the objects. Overall, the quality of the segmentation was deemed satisfactory.

## test_002 - OK

- measured objects: 25 (ground truth 31, regime normal)
- U-Net Dice: 0.9399
- count matches measurement: True

The segmentation mask for test_002 revealed 25 objects, with a mean area of 244 pixels. The object areas ranged from 76 to 556 pixels, indicating a relatively sparse distribution. The mean eccentricity and solidity values were 0.67 and 0.90, respectively, suggesting well-defined and compact objects. Overall, the quality of the segmentation was deemed satisfactory.

## test_003 - OK

- measured objects: 19 (ground truth 21, regime normal)
- U-Net Dice: 0.9352
- count matches measurement: True

The segmentation mask for test_003 yielded 19 objects, with a mean area of 223 pixels. The object areas ranged from 76 to 544 pixels, indicating a relatively sparse distribution. The mean eccentricity and solidity values were 0.67 and 0.92, respectively, suggesting well-defined and compact objects. Overall, the quality of the segmentation was deemed satisfactory.

## test_004 - OK

- measured objects: 42 (ground truth 75, regime dense)
- U-Net Dice: 0.9501
- count matches measurement: True

The segmentation mask for test_004 yielded a moderate density of objects, with a mean area of 351 pixels. The object areas ranged from 72 to 1372 pixels, indicating a wide range of sizes. The mean eccentricity and solidity values were 0.66 and 0.89, respectively, suggesting a generally well-defined shape for the objects. Overall, the quality of the segmentation was deemed satisfactory.

## test_005 - OK

- measured objects: 14 (ground truth 49, regime clustered)
- U-Net Dice: 0.9546
- count matches measurement: True

The segmentation mask in test_005 yielded 14 objects with a mean area of 485 pixels. The objects exhibited a dense distribution, with a mean eccentricity of 0.64 and a mean solidity of 0.89. The mean object intensity was 0.24. Overall, the segmentation quality was deemed satisfactory.

## test_006 - OK

- measured objects: 8 (ground truth 8, regime sparse)
- U-Net Dice: 0.9378
- count matches measurement: True

The segmentation mask for test_006 revealed 8 objects, with areas ranging from 88 to 344 pixels. The mean object area was 216 pixels, indicating a relatively uniform size distribution. The mean eccentricity and solidity values were 0.60 and 0.93, respectively, suggesting a well-defined and compact shape. Overall, the segmentation quality was deemed satisfactory.

## test_007 - FLAGGED

- measured objects: 23 (ground truth 30, regime normal)
- U-Net Dice: 0.9417
- count matches measurement: True

The segmentation mask in test_007 yielded an unexpected number of objects, which may indicate issues with the pipeline's detection accuracy. The mean object area was 217 pixels, with a range of 64 to 608 pixels, suggesting a mix of small and large objects. The mean eccentricity and solidity values were 0.62 and 0.91, respectively, indicating a relatively regular shape for the objects. However, the low mean object intensity of 0.24 may indicate issues with the segmentation algorithm's ability to accurately capture the object's boundaries.

## test_008 - OK

- measured objects: 22 (ground truth 28, regime normal)
- U-Net Dice: 0.944
- count matches measurement: True

The segmentation mask for test_008 yielded 22 objects, with a mean area of 264 pixels. The object sizes varied significantly, from 76 to 1080 pixels. The mean eccentricity and solidity values were 0.62 and 0.90, respectively, indicating relatively well-defined objects. Overall, the quality of the segmentation was deemed satisfactory.

## test_009 - OK

- measured objects: 21 (ground truth 24, regime normal)
- U-Net Dice: 0.9351
- count matches measurement: True

The segmentation mask for test_009 revealed a moderate density of objects, with a mean area of 195 pixels. The objects exhibited a range of sizes, from 92 to 448 pixels. The mean eccentricity and solidity values suggest that the objects are likely to be cell nuclei. Overall, the quality of the segmentation was deemed satisfactory.

## test_010 - OK

- measured objects: 33 (ground truth 78, regime dense)
- U-Net Dice: 0.9463
- count matches measurement: True

The segmentation mask for test_010 revealed a relatively sparse distribution of objects, with a mean area of 421 pixels. The objects exhibited a range of sizes, from 68 to 2336 pixels, and had a mean eccentricity of 0.71 and mean solidity of 0.88. However, the mean object intensity was low at 0.24, which may indicate potential issues with the segmentation pipeline. Overall, the quality of the segmentation mask was deemed satisfactory.

## test_011 - OK

- measured objects: 17 (ground truth 30, regime clustered)
- U-Net Dice: 0.9356
- count matches measurement: True

The segmentation mask for image test_011 revealed a moderate density of objects, with a mean area of 237 pixels. The objects exhibited a range of sizes, from 80 to 940 pixels, and had a mean eccentricity of 0.66 and mean solidity of 0.91. The quality of the segmentation was deemed satisfactory, with no obvious errors or inconsistencies.

