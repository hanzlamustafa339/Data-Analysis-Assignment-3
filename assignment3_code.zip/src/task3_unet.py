"""
Task 3 — train and evaluate the small U-Net, plus the loss ablation (extension).

Three identical U-Nets are trained, differing only in the loss (BCE, Dice,
BCE+Dice). Weight initialisation, batch order and augmentation draws are pinned
to the same seed in every run, so any difference we measure is caused by the
loss and not by luck. The BCE+Dice model is kept as the main model for Task 4.

Outputs
    models/unet_{loss}.pth          weights for each loss
    models/unet_main.pth            the model Task 4 loads
    metrics/unet_loss_ablation.csv  validation Dice/IoU per loss
    metrics/unet_per_image.csv      per-image val Dice/IoU, U-Net vs Otsu
    metrics/unet_history.json       loss and Dice curves
    figures/fig4_curves.png         training curves + ablation
    figures/fig5_predictions.png    input / ground truth / prediction panels
    figures/fig6_unet_vs_otsu.png   one image each way
"""

import json
import sys
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core import (DEVICE, FIG_DIR, METRIC_DIR, MODEL_DIR, UNET_SIZE, LOSSES,
                  NucleiDataset, UNet, dice_coefficient, iou_score, list_split,
                  load_gray, load_mask, load_metadata, mask_dice, mask_iou,
                  otsu_mask, region_table, segment_image, set_all_seeds)

N_EPOCHS = 20
BATCH_SIZE = 8
LR = 1e-3


@torch.no_grad()
def evaluate(model, loader):
    was_training = model.training
    model.eval()
    tot_d = tot_i = n = 0.0
    for x, y in loader:
        x, y = x.to(DEVICE), y.to(DEVICE)
        logits = model(x)
        bs = x.size(0)
        tot_d += dice_coefficient(logits, y) * bs
        tot_i += iou_score(logits, y) * bs
        n += bs
    model.train(was_training)
    return tot_d / n, tot_i / n


def train_model(loss_fn, train_ds, val_loader, n_epochs=N_EPOCHS, seed=0,
                label="model"):
    set_all_seeds(seed)
    model = UNet(base=16).to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    g = torch.Generator()
    g.manual_seed(seed)
    loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, generator=g)

    hist = {"train_loss": [], "val_loss": [], "val_dice": [], "val_iou": []}
    t0 = time.time()
    for epoch in range(n_epochs):
        model.train()
        running = 0.0
        for x, y in loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            optimizer.zero_grad()
            loss = loss_fn(model(x), y)
            loss.backward()
            optimizer.step()
            running += loss.item() * x.size(0)
        running /= len(train_ds)

        model.eval()
        v_loss = v_dice = v_iou = n = 0.0
        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(DEVICE), y.to(DEVICE)
                logits = model(x)
                bs = x.size(0)
                v_loss += loss_fn(logits, y).item() * bs
                v_dice += dice_coefficient(logits, y) * bs
                v_iou += iou_score(logits, y) * bs
                n += bs
        hist["train_loss"].append(running)
        hist["val_loss"].append(v_loss / n)
        hist["val_dice"].append(v_dice / n)
        hist["val_iou"].append(v_iou / n)
        print(f"  [{label:<9}] epoch {epoch+1:2d}/{n_epochs}  "
              f"train={running:.4f}  val={v_loss/n:.4f}  "
              f"val_Dice={v_dice/n:.4f}  ({time.time()-t0:.0f}s)", flush=True)
    return model, hist


def per_image_comparison(model):
    """Per-image U-Net vs Otsu on the validation split, plus object counts."""
    meta = load_metadata().set_index("image_id")
    rows = []
    for iid, ip, mp in list_split("val"):
        img256 = load_gray(ip)
        gt256 = load_mask(mp).astype(bool)
        gt128 = load_mask(mp, size=UNET_SIZE).astype(bool)

        pred128 = segment_image(model, load_gray(ip, size=UNET_SIZE,
                                                 normalise=True)).astype(bool)
        pred256 = segment_image(model, img256, out_size=256).astype(bool)
        otsu = otsu_mask(img256)

        n_unet = len(region_table(img256, pred256))
        n_otsu = len(region_table(img256, otsu))
        rows.append({
            "image_id": iid,
            "density": meta.loc[iid, "density"],
            "gt_objects": int(meta.loc[iid, "n_objects"]),
            # Two U-Net scores. `unet_dice` is measured at the network's native
            # 128x128 (the honest number for the model itself). `unet_dice_256`
            # upsamples the prediction to 256 and scores it against the
            # full-resolution ground truth, which is the only fair way to
            # compare against Otsu — Otsu never leaves 256x256, so scoring the
            # U-Net at 128 would confound the model with the resolution.
            "unet_dice": round(mask_dice(pred128, gt128), 4),
            "unet_iou": round(mask_iou(pred128, gt128), 4),
            "unet_dice_256": round(mask_dice(pred256, gt256), 4),
            "unet_iou_256": round(mask_iou(pred256, gt256), 4),
            "otsu_dice": round(mask_dice(otsu, gt256), 4),
            "otsu_iou": round(mask_iou(otsu, gt256), 4),
            "unet_objects": n_unet,
            "otsu_objects": n_otsu,
        })
    df = pd.DataFrame(rows)
    df["unet_minus_otsu"] = (df.unet_dice_256 - df.otsu_dice).round(4)
    df.to_csv(METRIC_DIR / "unet_per_image.csv", index=False)
    return df


def figure_curves(histories, ablation):
    fig, axes = plt.subplots(1, 3, figsize=(16, 4.2))
    colours = {"BCE": "#4C72B0", "Dice": "#DD8452", "BCE+Dice": "#55A868"}

    for name, h in histories.items():
        axes[0].plot(range(1, len(h["train_loss"]) + 1), h["train_loss"],
                     color=colours[name], label=f"{name} (train)")
        axes[0].plot(range(1, len(h["val_loss"]) + 1), h["val_loss"], "--",
                     color=colours[name], alpha=0.7, label=f"{name} (val)")
    axes[0].set_xlabel("epoch")
    axes[0].set_ylabel("loss (own scale per model)")
    axes[0].set_title("(a) Loss curves")
    axes[0].legend(fontsize=7)
    axes[0].grid(alpha=0.3)

    for name, h in histories.items():
        axes[1].plot(range(1, len(h["val_dice"]) + 1), h["val_dice"],
                     color=colours[name], label=name)
    axes[1].set_xlabel("epoch")
    axes[1].set_ylabel("validation Dice")
    axes[1].set_title("(b) Validation Dice — the only comparable curve")
    axes[1].set_ylim(0, 1)
    axes[1].legend(fontsize=8)
    axes[1].grid(alpha=0.3)

    x = np.arange(len(ablation))
    axes[2].bar(x - 0.2, ablation.val_dice, 0.4, label="Dice", color="#55A868")
    axes[2].bar(x + 0.2, ablation.val_iou, 0.4, label="IoU", color="#4C72B0")
    axes[2].set_xticks(x)
    axes[2].set_xticklabels(ablation.loss)
    axes[2].set_ylim(0.8, 1.0)
    axes[2].set_ylabel("validation score")
    axes[2].set_title("(c) Loss ablation (final epoch)")
    axes[2].legend(fontsize=8)
    axes[2].grid(alpha=0.3, axis="y")

    fig.suptitle("Task 3 — U-Net training and loss ablation "
                 f"({N_EPOCHS} epochs, {UNET_SIZE}x{UNET_SIZE} input)", fontsize=12)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig4_curves.png", dpi=160, bbox_inches="tight")
    plt.close(fig)


def figure_predictions(model, per_image, n_show=4):
    """Input / ground truth / prediction / error map for the extremes."""
    order = per_image.sort_values("unet_dice")
    picks = list(order.head(2).image_id) + list(order.tail(2).image_id)
    picks = picks[:n_show]

    fig, axes = plt.subplots(len(picks), 4, figsize=(13, 3.2 * len(picks)))
    for r, iid in enumerate(picks):
        ip = list(Path(f"data/val/images").glob(f"{iid}.png"))[0]
        mp = Path(f"data/val/masks/{iid}.png")
        img = load_gray(ip, size=UNET_SIZE, normalise=True)
        gt = load_mask(mp, size=UNET_SIZE).astype(bool)
        pred = segment_image(model, img).astype(bool)
        err = np.zeros((*gt.shape, 3))
        err[..., 0] = pred & ~gt      # false positive: red
        err[..., 1] = gt & pred       # correct: green
        err[..., 2] = gt & ~pred      # false negative: blue
        row = per_image[per_image.image_id == iid].iloc[0]

        for c, (im, title, cmap) in enumerate([
            (img, f"{iid} ({row.density})", "gray"),
            (gt, f"ground truth — {row.gt_objects} nuclei", "gray"),
            (pred, f"U-Net — Dice {row.unet_dice:.3f}", "gray"),
            (err, "green=hit  red=FP  blue=FN", None),
        ]):
            axes[r, c].imshow(im, cmap=cmap)
            axes[r, c].set_title(title, fontsize=9)
            axes[r, c].axis("off")
    fig.suptitle("Task 3 — worst two and best two validation images", fontsize=12)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig5_predictions.png", dpi=160, bbox_inches="tight")
    plt.close(fig)


def figure_unet_vs_otsu(model, per_image):
    """Each method wins on a different criterion, so show one of each.

    Otsu has the higher pixel Dice on every validation image. The U-Net's
    advantage is at the object level: it separates touching nuclei slightly
    more often, so its component count is closer to the truth. Picking the
    'winner' by Dice alone would hide that entirely.
    """
    pi = per_image.copy()
    pi["unet_count_err"] = (pi.unet_objects - pi.gt_objects).abs()
    pi["otsu_count_err"] = (pi.otsu_objects - pi.gt_objects).abs()
    pi["count_gain"] = pi.otsu_count_err - pi.unet_count_err

    unet_case = pi.sort_values("count_gain").iloc[-1]     # U-Net counts best
    otsu_case = pi.sort_values("unet_minus_otsu").iloc[0]  # Otsu's biggest Dice win

    fig, axes = plt.subplots(2, 4, figsize=(13, 6.6))
    for r, (row, winner) in enumerate([
            (unet_case, "U-Net closer on object count"),
            (otsu_case, "Otsu clearly higher Dice")]):
        iid = row.image_id
        img = load_gray(f"data/val/images/{iid}.png")
        gt = load_mask(f"data/val/masks/{iid}.png").astype(bool)
        unet = segment_image(model, img, out_size=256).astype(bool)
        otsu = otsu_mask(img)
        for c, (im, title) in enumerate([
            (img, f"{iid} ({row.density}) — {winner}"),
            (gt, f"ground truth — {row.gt_objects} nuclei"),
            (unet, f"U-Net: Dice {row.unet_dice_256:.3f}, "
                   f"{row.unet_objects} obj"),
            (otsu, f"Otsu: Dice {row.otsu_dice:.3f}, "
                   f"{row.otsu_objects} obj"),
        ]):
            axes[r, c].imshow(im, cmap="gray")
            axes[r, c].set_title(title, fontsize=9)
            axes[r, c].axis("off")
    fig.suptitle("Task 3 — pixel overlap and object count disagree about the winner",
                 fontsize=12)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig6_unet_vs_otsu.png", dpi=160, bbox_inches="tight")
    plt.close(fig)


def train_one(name):
    """Train a single loss variant and persist weights + history."""
    train_ds = NucleiDataset("train", augment=True)
    val_ds = NucleiDataset("val", augment=False)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False)
    model, hist = train_model(LOSSES[name], train_ds, val_loader, label=name)
    d, i = evaluate(model, val_loader)
    tag = name.replace("+", "_")
    torch.save(model.state_dict(), MODEL_DIR / f"unet_{tag}.pth")
    (METRIC_DIR / f"history_{tag}.json").write_text(
        json.dumps({"loss": name, "val_dice": d, "val_iou": i, "history": hist},
                   indent=2))
    print(f"  -> {name}: Dice={d:.4f}  IoU={i:.4f}")
    return d, i


def finalise():
    """Collect the three runs, build the ablation table and every figure."""
    histories, rows = {}, []
    for name in LOSSES:
        tag = name.replace("+", "_")
        blob = json.loads((METRIC_DIR / f"history_{tag}.json").read_text())
        histories[name] = blob["history"]
        rows.append({"loss": name,
                     "val_dice": round(blob["val_dice"], 4),
                     "val_iou": round(blob["val_iou"], 4),
                     "final_train_loss": round(blob["history"]["train_loss"][-1], 4)})
    ablation = pd.DataFrame(rows)
    ablation.to_csv(METRIC_DIR / "unet_loss_ablation.csv", index=False)
    (METRIC_DIR / "unet_history.json").write_text(json.dumps(histories, indent=2))
    print(ablation.to_string(index=False))

    main_model = UNet(base=16).to(DEVICE)
    main_model.load_state_dict(torch.load(MODEL_DIR / "unet_BCE_Dice.pth",
                                          map_location=DEVICE))
    main_model.eval()
    torch.save(main_model.state_dict(), MODEL_DIR / "unet_main.pth")

    per_image = per_image_comparison(main_model)
    figure_curves(histories, ablation)
    figure_predictions(main_model, per_image)
    figure_unet_vs_otsu(main_model, per_image)
    return per_image


if __name__ == "__main__":
    arg = sys.argv[1] if len(sys.argv) > 1 else "all"
    print(f"Device: {DEVICE}  |  input {UNET_SIZE}x{UNET_SIZE}  |  "
          f"{N_EPOCHS} epochs per model", flush=True)

    if arg in LOSSES:
        train_one(arg)
        sys.exit(0)

    if arg == "all":
        for name in LOSSES:
            train_one(name)

    per_image = finalise()

    print("\nPer-image validation summary (BCE+Dice model):")
    print(per_image.groupby("density")[["unet_dice", "unet_dice_256", "otsu_dice",
                                        "unet_objects", "otsu_objects",
                                        "gt_objects"]].mean().round(3).to_string())
    print(f"\nOverall  U-Net@128 Dice={per_image.unet_dice.mean():.4f} "
          f"IoU={per_image.unet_iou.mean():.4f}  |  "
          f"U-Net@256 Dice={per_image.unet_dice_256.mean():.4f} "
          f"IoU={per_image.unet_iou_256.mean():.4f}  |  "
          f"Otsu@256 Dice={per_image.otsu_dice.mean():.4f} "
          f"IoU={per_image.otsu_iou.mean():.4f}")
    print("\nTask 3 complete.")
