"""
Task 1 — data preparation, EDA, and the direct multimodal (VLM) description.

Outputs
    figures/fig1_samples.png        sample images with their ground-truth masks
    figures/fig2_histograms.png     intensity histograms + per-density summary
    metrics/eda_summary.csv         per-split image statistics
    records/task1_vlm.json          naive vs structured prompt, 3 repeat runs
"""

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core import (DATA_DIR, FIG_DIR, METRIC_DIR, RECORD_DIR, ANALYSIS_SIZE,
                  list_split, load_gray, load_mask, load_metadata)
from llm import PROMPT_T1_NAIVE, PROMPT_T1_STRUCTURED, chat_local, parse_model_json


def figure_samples(meta):
    """One example per density regime, image over ground-truth mask."""
    regimes = ["sparse", "normal", "dense", "clustered"]
    train = meta[meta.split == "train"]
    fig, axes = plt.subplots(2, 4, figsize=(14, 7.2))
    for j, reg in enumerate(regimes):
        row = train[train.density == reg].iloc[0]
        iid = row.image_id
        img = load_gray(DATA_DIR / "train" / "images" / f"{iid}.png")
        msk = load_mask(DATA_DIR / "train" / "masks" / f"{iid}.png")
        axes[0, j].imshow(img, cmap="gray", vmin=0, vmax=float(img.max()))
        axes[0, j].set_title(f"{reg}\n{iid} — {int(row.n_objects)} nuclei", fontsize=10)
        axes[1, j].imshow(msk, cmap="gray", vmin=0, vmax=1)
        axes[1, j].set_title(f"ground-truth mask ({row.area_fraction*100:.1f}% fg)",
                             fontsize=9)
        for i in (0, 1):
            axes[i, j].axis("off")
    fig.suptitle("Task 1 — grayscale nuclei images at 256x256, one per density regime",
                 fontsize=12)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig1_samples.png", dpi=160, bbox_inches="tight")
    plt.close(fig)


def figure_histograms(meta):
    """Intensity histograms: whole-image, and foreground vs background."""
    train = meta[meta.split == "train"]
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.2))

    # (a) per-regime whole-image histograms
    for reg, colour in zip(["sparse", "normal", "dense", "clustered"],
                           ["#4C72B0", "#DD8452", "#55A868", "#C44E52"]):
        iid = train[train.density == reg].iloc[0].image_id
        img = load_gray(DATA_DIR / "train" / "images" / f"{iid}.png")
        axes[0].hist(img.ravel(), bins=80, range=(0, 0.5), histtype="step",
                     label=reg, color=colour, linewidth=1.4)
    axes[0].set_yscale("log")
    axes[0].set_xlabel("grayscale intensity")
    axes[0].set_ylabel("pixel count (log)")
    axes[0].set_title("(a) Whole-image histogram by density regime")
    axes[0].legend(fontsize=8)

    # (b) foreground vs background over 20 training images
    fg, bg = [], []
    for iid in train.image_id.head(20):
        img = load_gray(DATA_DIR / "train" / "images" / f"{iid}.png")
        msk = load_mask(DATA_DIR / "train" / "masks" / f"{iid}.png").astype(bool)
        fg.append(img[msk])
        bg.append(img[~msk])
    fg, bg = np.concatenate(fg), np.concatenate(bg)
    axes[1].hist(bg, bins=80, range=(0, 0.5), alpha=0.6, label="background",
                 color="#8C8C8C", density=True)
    axes[1].hist(fg, bins=80, range=(0, 0.5), alpha=0.6, label="nuclei",
                 color="#4C72B0", density=True)
    axes[1].set_xlabel("grayscale intensity")
    axes[1].set_ylabel("density")
    axes[1].set_title("(b) Foreground vs background (20 train images)")
    axes[1].legend(fontsize=8)

    # (c) object count by regime
    order = ["sparse", "normal", "dense", "clustered"]
    data = [meta[meta.density == r].n_objects.values for r in order]
    axes[2].boxplot(data, tick_labels=order)
    axes[2].set_ylabel("nuclei per image (ground truth)")
    axes[2].set_title("(c) Object count by regime (all 112 images)")
    axes[2].tick_params(axis="x", labelsize=9)

    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig2_histograms.png", dpi=160, bbox_inches="tight")
    plt.close(fig)
    return fg, bg


def eda_table(meta, fg, bg):
    rows = []
    for split in ["train", "val", "test"]:
        items = list_split(split)
        stats = []
        for iid, ip, mp in items:
            img = load_gray(ip)
            stats.append((img.mean(), img.std(), img.max()))
        s = np.array(stats)
        sub = meta[meta.split == split]
        rows.append({
            "split": split,
            "n_images": len(items),
            "size": f"{ANALYSIS_SIZE}x{ANALYSIS_SIZE}",
            "mean_intensity": round(float(s[:, 0].mean()), 4),
            "std_intensity": round(float(s[:, 1].mean()), 4),
            "gt_objects_mean": round(float(sub.n_objects.mean()), 1),
            "gt_objects_min": int(sub.n_objects.min()),
            "gt_objects_max": int(sub.n_objects.max()),
            "gt_area_fraction": round(float(sub.area_fraction.mean()), 4),
        })
    df = pd.DataFrame(rows)
    df.to_csv(METRIC_DIR / "eda_summary.csv", index=False)
    sep = (fg.mean() - bg.mean()) / np.sqrt(0.5 * (fg.var() + bg.var()))
    print(df.to_string(index=False))
    print(f"\nForeground/background separability (Cohen's d): {sep:.2f}")
    return df, float(sep)


def vlm_experiments(model="llama3.2-vision"):
    """Naive vs structured prompt, plus a stochasticity check at two temperatures."""
    iid, ipath, _ = list_split("train")[1]   # a 'normal' density image
    out = {"image_id": iid, "image_path": str(ipath), "model": model}

    naive_text, src = chat_local(PROMPT_T1_NAIVE, model=model,
                                 images=[str(ipath)], temperature=0.0)
    out["llm_source"] = src
    out["naive"] = {"prompt": PROMPT_T1_NAIVE, "response": naive_text}

    struct_text, _ = chat_local(PROMPT_T1_STRUCTURED, model=model,
                                images=[str(ipath)], temperature=0.0)
    out["structured"] = {
        "prompt": PROMPT_T1_STRUCTURED,
        "response": struct_text,
        "parsed": parse_model_json(struct_text),
        "parsed_ok": "error" not in parse_model_json(struct_text),
    }

    # Repeated runs: temperature 0.8 should vary, temperature 0 should not.
    for temp in (0.8, 0.0):
        runs = [chat_local(PROMPT_T1_STRUCTURED, model=model,
                           images=[str(ipath)], temperature=temp)[0]
                for _ in range(3)]
        out[f"repeat_temp_{temp}"] = {
            "runs": runs,
            "identical": len(set(runs)) == 1,
            "n_distinct": len(set(runs)),
        }

    (RECORD_DIR / "task1_vlm.json").write_text(json.dumps(out, indent=2))
    print(f"\nVLM step source: {src}")
    print(f"  structured JSON parsed: {out['structured']['parsed_ok']}")
    print(f"  temp=0.8 identical across 3 runs: {out['repeat_temp_0.8']['identical']}")
    print(f"  temp=0.0 identical across 3 runs: {out['repeat_temp_0.0']['identical']}")
    return out


if __name__ == "__main__":
    meta = load_metadata()
    figure_samples(meta)
    fg, bg = figure_histograms(meta)
    eda_table(meta, fg, bg)
    vlm_experiments()
    print("\nTask 1 complete.")
