"""
llm.py — every LLM interaction in the assignment, in one place.

Two things matter here.

1. All prompts are literals in this file, so the report can quote exactly what
   was sent. Nothing is assembled at call time except the {placeholders}.

2. `chat_local` talks to a local Ollama server (as in Labs 2, 4 and 5). If no
   server is reachable — which is the case in any environment without Ollama
   installed — it falls back to a deterministic offline stub and stamps every
   record with llm_source="offline_stub". The stub exists so the pipeline can be
   developed and tested end to end; the numbers in it are taken from the
   measured feature table, never invented. Re-run with Ollama running and every
   record is stamped llm_source="<model name>" instead.
"""

import json
import os
import re

OLLAMA_AVAILABLE = None  # resolved lazily on first call


# ==========================================================================
# PROMPTS — Task 1
# ==========================================================================

# The naive baseline the assignment asks us to compare against.
PROMPT_T1_NAIVE = "What is this?"

# The optimised prompt. Design choices, each addressing a failure mode seen in
# Lab 2: role + rules + format (the lab's workhorse pattern); an explicit
# descriptive-not-diagnostic anchor; a closed vocabulary for every categorical
# field so the output is machine-comparable; "uncertain" made an allowed value
# so the model has a legal way to decline rather than confabulate; and a hard
# JSON-only instruction because free text before the object breaks json.loads.
PROMPT_T1_STRUCTURED = '''You are assisting a researcher by DESCRIBING a biomedical image.
You are not making a diagnosis and you must not suggest one.

Return ONLY valid JSON. No commentary, no markdown code fences, no text before
or after the object.

Fields:
- modality (string: "fluorescence microscopy", "brightfield microscopy",
  "histology", "fundus photograph", "x-ray", "ct", "mri", or "uncertain")
- tissue_type (string: short noun phrase, or "uncertain")
- notable_features (list of up to 3 short noun phrases describing only what is
  visible: e.g. "round bright objects", "dark background", "clustered objects")
- image_quality (string: "good", "acceptable", "poor", or "uncertain")

Rules:
- Describe only what is visible. Do NOT infer a disease, a stain name, a
  species, a magnification, or a scale bar unless it is literally visible.
- If you are not confident about a field, output "uncertain" (or an empty list
  for notable_features). "uncertain" is a correct answer, not a failure.
- Do not count objects; you are not being asked for a number.
- Output must parse with json.loads.'''


# ==========================================================================
# PROMPTS — Task 2 (numbers-first: the model never sees the image)
# ==========================================================================

PROMPT_T2_NUMBERS = '''You are writing the description section of a biomedical
image-analysis report. You have NOT seen the image. You have only the
measurements below, produced by a deterministic image-processing pipeline.

Based ONLY on those measurements:

1. Produce a JSON record with these fields:
   - n_objects (integer, copied exactly from the summary)
   - density_class ("sparse", "moderate", "dense")
   - shape_regularity ("highly irregular", "irregular", "regular", "highly regular")
   - quality_flag ("ok", "review_recommended", "fail")

2. Then a one-paragraph description (3-4 sentences) of the measured objects.

Format your response EXACTLY as:

JSON:
{{...}}

NARRATIVE:
<paragraph>

Rules:
- Every number you state must appear in the summary. Do NOT compute new
  numbers and do NOT invent any.
- Do NOT describe colour, staining, texture, or anything else you cannot know
  from measurements alone.
- Do NOT diagnose any medical condition.
- Interpret eccentricity as 0 = circular and 1 = elongated; solidity as
  1 = smooth convex boundary and lower = ragged or touching objects.

Measurements: {summary}'''


# ==========================================================================
# PROMPTS — Task 4 (hybrid pipeline record)
# ==========================================================================

PROMPT_T4_HYBRID = '''You are summarising a biomedical image for a research report.

You will be given a textual summary of measurements taken from a segmentation
mask. Based ONLY on that summary:

1. Produce a JSON record with these fields:
   - image_id (string, copied exactly from the summary)
   - n_objects (integer, copied exactly from the summary)
   - mean_area (number, copied exactly from the summary)
   - density_class ("sparse", "moderate", "dense")
   - quality_flag ("ok", "review_recommended", "fail")

2. Then a one-paragraph narrative (3-4 sentences) suitable for a research report.

Format your response EXACTLY as:

JSON:
{{...}}

NARRATIVE:
<paragraph>

Rules:
- Do NOT invent details that are not in the summary.
- Do NOT diagnose any medical condition.
- Copy n_objects and mean_area verbatim; they are measurements, not estimates.
- If the summary reports no objects, or object counts or sizes that look
  implausible for cell nuclei, set quality_flag to "fail".

Image ID: {image_id}
Summary: {summary}'''


# ==========================================================================
# Client
# ==========================================================================

def _ollama_up():
    global OLLAMA_AVAILABLE
    if OLLAMA_AVAILABLE is None:
        try:
            import urllib.request
            host = os.environ.get("OLLAMA_HOST", "127.0.0.1:11434")
            urllib.request.urlopen(f"http://{host}/api/tags", timeout=2)
            OLLAMA_AVAILABLE = True
        except Exception:
            OLLAMA_AVAILABLE = False
    return OLLAMA_AVAILABLE


def chat_local(prompt, model="llama3.2", images=None, temperature=0.0):
    """Send a prompt (optionally with images) to a local Ollama model.

    Returns (text, source) where source is the model name or "offline_stub".
    """
    if _ollama_up():
        from ollama import chat

        msg = {"role": "user", "content": prompt}
        if images:
            msg["images"] = list(images)
        resp = chat(model=model, messages=[msg],
                    options={"temperature": temperature})
        return resp["message"]["content"], model
    return _offline_stub(prompt, images=images), "offline_stub"


# --------------------------------------------------------------------------
# Offline stub
# --------------------------------------------------------------------------

def _offline_stub(prompt, images=None):
    """Deterministic stand-in used only when no Ollama server is reachable.

    It reads the numbers back out of the prompt rather than inventing any, so
    downstream parsing, auditing and CSV assembly can be tested exactly as they
    will behave with a real model. It is NOT a language model and its prose is
    templated.
    """
    if images is not None:
        # Task 1 shape: a JSON-only image description.
        return json.dumps({
            "modality": "fluorescence microscopy",
            "tissue_type": "cell nuclei",
            "notable_features": ["round bright objects", "dark background",
                                 "some touching objects"],
            "image_quality": "good",
        })

    def _num(pattern, cast=float, default=0):
        m = re.search(pattern, prompt)
        return cast(m.group(1)) if m else default

    n = _num(r"detected (\d+) objects", int, 0)
    mean_area = _num(r"mean (\d+), median", float, 0.0)
    ecc = _num(r"Mean eccentricity is ([0-9]+\.?[0-9]*)", float, 0.0)
    sol = _num(r"mean solidity is ([0-9]+\.?[0-9]*)", float, 0.0)
    a_min = _num(r"range from (\d+) to", float, 0.0)
    a_max = _num(r"to (\d+) pixels", float, 0.0)
    m_id = re.search(r"Image ID: (\S+)", prompt)
    image_id = m_id.group(1) if m_id else "unknown"

    density = "sparse" if n < 15 else ("moderate" if n < 45 else "dense")
    regularity = ("highly regular" if ecc < 0.5 else
                  "regular" if ecc < 0.75 else
                  "irregular" if ecc < 0.9 else "highly irregular")
    quality = "ok" if (n > 0 and mean_area >= 20) else "fail"

    narrative = (
        f"The segmentation identified {n} discrete objects, with areas from "
        f"{a_min:.0f} to {a_max:.0f} pixels and a mean of {mean_area:.0f} pixels. "
        f"A mean eccentricity of {ecc:.2f} indicates predominantly "
        f"{'rounded' if ecc < 0.75 else 'elongated'} objects, and a mean solidity "
        f"of {sol:.2f} suggests {'smooth, convex' if sol > 0.9 else 'partly ragged or merged'} "
        f"boundaries. The object count places this field in the {density} regime. "
        f"These are descriptive measurements only and carry no diagnostic meaning."
    )

    if "image_id" in prompt:  # Task 4 schema
        record = {"image_id": image_id, "n_objects": n,
                  "mean_area": round(mean_area, 1),
                  "density_class": density, "quality_flag": quality}
    else:                      # Task 2 schema
        record = {"n_objects": n, "density_class": density,
                  "shape_regularity": regularity, "quality_flag": quality}

    return f"JSON:\n{json.dumps(record)}\n\nNARRATIVE:\n{narrative}"


# --------------------------------------------------------------------------
# Parsing (Lab 5)
# --------------------------------------------------------------------------

def parse_model_json(text):
    """Parse a JSON-only reply, stripping markdown fences if present (Lab 2)."""
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1]
        if text.endswith("```"):
            text = text.rsplit("```", 1)[0]
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Last resort: grab the outermost {...} block.
        m = re.search(r"\{.*\}", text, re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                pass
        return {"error": "could not parse JSON"}


def _extract_json_block(text):
    """Return (json_string, remainder) by brace-matching the first {...} block."""
    start = text.find("{")
    if start == -1:
        return None, text
    depth = 0
    for i, ch in enumerate(text[start:], start):
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start:i + 1], text[i + 1:]
    return text[start:], ""


def parse_hybrid_response(text):
    """Split a combined JSON + narrative reply into (record, narrative).

    Deliberately tolerant. Splitting on a literal "NARRATIVE:" loses the
    paragraph whenever the model writes "**Narrative:**", "narrative -", or
    omits the marker and just starts the prose; in the first Colab run that cost
    9 of 12 narratives. Instead we brace-match the JSON object and treat
    everything after it as the narrative, stripping any marker we find.
    """
    text = text.strip()
    json_str, rest = _extract_json_block(text)
    if json_str is not None and rest.lstrip().startswith("```"):
        rest = rest.lstrip()[3:]          # closing fence of a ```json block
    record = parse_model_json(json_str) if json_str else {"error": "no JSON found"}
    rest = rest.strip().lstrip("`").strip()
    rest = re.sub(r"^[\s`*#_>-]*narrative[\s*:._>-]*", "", rest, flags=re.I)
    return record, rest.strip().strip("`").strip()
