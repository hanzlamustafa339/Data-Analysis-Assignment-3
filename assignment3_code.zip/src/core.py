"""
core.py — shared building blocks for the hybrid biomedical image-analysis pipeline.

Everything that more than one task needs lives here:
  * dataset loading / grayscale conversion          (Task 1)
  * the classical Otsu + morphology + regionprops   (Task 2, from Lab 3)
  * the 3-level U-Net, losses and metrics           (Task 3, from Lab 4)
  * segment_image() and the feature summariser      (Task 4, from Lab 4/5)

The U-Net class, DoubleConv, dice_loss, combined_loss, dice_coefficient,
iou_score and segment_image are kept structurally identical to the versions in
LAB_CNN_unet_segmentation.ipynb and lab5_hybrid_unet_llm_colab.ipynb so that
weights and helpers stay interchangeable with the lab notebooks.
"""

import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from skimage import filters as skfilters
from skimage import measure as skmeasure
from skimage import morphology as skmorphology
from skimage.color import rgb2gray
from skimage.morphology import disk
from skimage.transform import resize
from torch.utils.data import Dataset

# --------------------------------------------------------------------------
# Paths and constants
# --------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
OUT_DIR = PROJECT_ROOT / "outputs"
FIG_DIR = OUT_DIR / "figures"
METRIC_DIR = OUT_DIR / "metrics"
RECORD_DIR = OUT_DIR / "records"
MODEL_DIR = PROJECT_ROOT / "models"

for _p in (FIG_DIR, METRIC_DIR, RECORD_DIR, MODEL_DIR):
    _p.mkdir(parents=True, exist_ok=True)

# The assignment asks for images at a common 256x256 size; the dataset is
# already native 256x256, so ANALYSIS_SIZE is a no-op resize that documents the
# requirement and would rescale anything non-conforming.
ANALYSIS_SIZE = 256

# Lab 4 trained its U-Net at 128x128. We keep that input size: at 256x256 a
# single training run costs ~56 min on one CPU core versus ~5 min at 128, which
# would make the loss ablation impractical. Predicted masks are resized back to
# 256 (nearest-neighbour) before regionprops so that object areas stay in the
# same pixel units as the ground-truth metadata.
UNET_SIZE = 128

SEED = 42

# scikit-image 0.26 deprecates remove_small_objects(min_size=...) in favour of
# max_size with different semantics. Colab still ships an older version, so we
# keep the lab-compatible call and silence the forward-looking warning.
warnings.filterwarnings("ignore", category=FutureWarning, module="skimage")
warnings.filterwarnings("ignore", message=".*min_size.*")


def set_all_seeds(seed=SEED):
    """Pin NumPy and Torch RNGs (weight init, batch order, augmentation draws)."""
    np.random.seed(seed)
    torch.manual_seed(seed)


DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# --------------------------------------------------------------------------
# Task 1 — loading and grayscale conversion
# --------------------------------------------------------------------------

def to_unit_range(a):
    """Min-max normalise to [0, 1] float32; safe on a constant image."""
    a = np.asarray(a, dtype=np.float32)
    lo, hi = float(a.min()), float(a.max())
    return (a - lo) / (hi - lo) if hi - lo > 1e-8 else np.zeros_like(a)


def load_gray(path, size=ANALYSIS_SIZE, normalise=False):
    """Read a PNG, convert to grayscale float32 in [0, 1], resize to `size`.

    Note on the colour conversion: these are DAPI-like images where the signal
    is mostly in the blue channel (B = I, G = 0.35I, R = 0.12I), and rgb2gray
    weights blue at only 0.0721. The conversion is therefore a *linear* rescale
    of the underlying intensity (~0.35I), not a loss of information, because the
    three channels are perfectly correlated by construction. Otsu is invariant
    to that rescale. We still normalise per image afterwards so that the U-Net
    and the histograms see a consistent dynamic range.
    """
    from imageio.v2 import imread

    arr = imread(path)
    arr = np.asarray(arr)
    if arr.ndim == 3:
        gray = rgb2gray(arr[..., :3])
    else:
        gray = arr.astype(np.float32)
        if gray.max() > 1.0:
            gray = gray / 255.0
    if gray.shape != (size, size):
        gray = resize(gray, (size, size), anti_aliasing=True, preserve_range=True)
    gray = np.asarray(gray, dtype=np.float32)
    return to_unit_range(gray) if normalise else np.clip(gray, 0, 1)


def load_mask(path, size=ANALYSIS_SIZE):
    """Read a binary mask PNG as float32 {0., 1.} at `size`."""
    from imageio.v2 import imread

    m = np.asarray(imread(path)).astype(np.float32)
    if m.ndim == 3:
        m = m[..., 0]
    m = (m > 127).astype(np.float32)
    if m.shape != (size, size):
        m = resize(m, (size, size), order=0, anti_aliasing=False,
                   preserve_range=True)
    return (m > 0.5).astype(np.float32)


def list_split(split):
    """Sorted list of (image_id, image_path, mask_path) for a split."""
    img_dir = DATA_DIR / split / "images"
    mask_dir = DATA_DIR / split / "masks"
    out = []
    for p in sorted(img_dir.glob("*.png")):
        out.append((p.stem, p, mask_dir / p.name))
    return out


def load_metadata():
    return pd.read_csv(DATA_DIR / "metadata.csv")


# --------------------------------------------------------------------------
# Task 2 — classical pipeline (Lab 3, Exercise 7.1)
# --------------------------------------------------------------------------

CLASSICAL_PROPS = ("label", "area", "perimeter", "eccentricity", "solidity",
                   "major_axis_length", "minor_axis_length", "mean_intensity")


def otsu_mask(gray_img, gauss_sigma=1.0, open_r=1, close_r=2, min_area=30):
    """Lab 3's mask: Gaussian smooth -> Otsu -> opening -> closing -> despeckle."""
    smooth = skfilters.gaussian(gray_img, sigma=gauss_sigma)
    T = skfilters.threshold_otsu(smooth)
    mask = smooth >= T
    mask = skmorphology.opening(mask, disk(open_r))
    mask = skmorphology.closing(mask, disk(close_r))
    mask = skmorphology.remove_small_objects(mask, min_size=min_area)
    return mask.astype(bool)


def region_table(gray_img, mask, min_area=30):
    """Binary mask -> per-object regionprops DataFrame (the auditable numbers)."""
    mask = skmorphology.remove_small_objects(np.asarray(mask).astype(bool),
                                             min_size=min_area)
    labels = skmeasure.label(mask)
    if labels.max() == 0:
        return pd.DataFrame(columns=list(CLASSICAL_PROPS))
    props = skmeasure.regionprops_table(
        labels,
        intensity_image=np.asarray(gray_img, dtype=float),
        properties=CLASSICAL_PROPS,
    )
    df = pd.DataFrame(props)
    # circularity is not a regionprops property in every skimage version, so we
    # derive it: 4*pi*area / perimeter^2, which is 1.0 for a perfect circle.
    # circularity = 4*pi*area / perimeter^2 (1.0 for a perfect circle). Left
    # unclipped: skimage's perimeter estimator can under-measure small objects,
    # which pushes the ratio slightly above 1 — clipping would hide that.
    per = df["perimeter"].replace(0, np.nan)
    df["circularity"] = 4 * np.pi * df["area"] / (per ** 2)
    return df.round(3)


def analyse_cells(gray_img, **kwargs):
    """Lab 3 end-to-end: grayscale image -> regionprops DataFrame (Otsu route)."""
    mask = otsu_mask(gray_img, **kwargs)
    return region_table(gray_img, mask, min_area=kwargs.get("min_area", 30)), mask


# --------------------------------------------------------------------------
# Task 3 — the U-Net (verbatim structure from Lab 4)
# --------------------------------------------------------------------------

class DoubleConv(nn.Module):
    """Two 3x3 convolutions with batch norm and ReLU, the basic U-Net block."""

    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class UNet(nn.Module):
    def __init__(self, in_ch=1, out_ch=1, base=16):
        super().__init__()
        self.enc1 = DoubleConv(in_ch, base)
        self.enc2 = DoubleConv(base, base * 2)
        self.enc3 = DoubleConv(base * 2, base * 4)
        self.bottleneck = DoubleConv(base * 4, base * 8)
        self.up3 = nn.ConvTranspose2d(base * 8, base * 4, 2, stride=2)
        self.dec3 = DoubleConv(base * 8, base * 4)
        self.up2 = nn.ConvTranspose2d(base * 4, base * 2, 2, stride=2)
        self.dec2 = DoubleConv(base * 4, base * 2)
        self.up1 = nn.ConvTranspose2d(base * 2, base, 2, stride=2)
        self.dec1 = DoubleConv(base * 2, base)
        self.out_conv = nn.Conv2d(base, out_ch, kernel_size=1)
        self.pool = nn.MaxPool2d(2)

    def forward(self, x):
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))
        e3 = self.enc3(self.pool(e2))
        b = self.bottleneck(self.pool(e3))
        d3 = self.up3(b)
        d3 = self.dec3(torch.cat([d3, e3], dim=1))
        d2 = self.up2(d3)
        d2 = self.dec2(torch.cat([d2, e2], dim=1))
        d1 = self.up1(d2)
        d1 = self.dec1(torch.cat([d1, e1], dim=1))
        return self.out_conv(d1)


# ---- losses -------------------------------------------------------------

def dice_loss(logits, target, eps=1e-7):
    """Soft Dice loss in [0, 1]. Lower is better."""
    probs = torch.sigmoid(logits)
    intersection = (probs * target).sum(dim=(1, 2, 3))
    union = probs.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3))
    dice = (2 * intersection + eps) / (union + eps)
    return 1 - dice.mean()


def bce_loss(logits, target):
    return F.binary_cross_entropy_with_logits(logits, target)


def combined_loss(logits, target):
    return bce_loss(logits, target) + dice_loss(logits, target)


LOSSES = {"BCE": bce_loss, "Dice": dice_loss, "BCE+Dice": combined_loss}


# ---- metrics ------------------------------------------------------------

def dice_coefficient(logits, target, threshold=0.5, eps=1e-7):
    """Hard Dice after thresholding. Higher is better."""
    preds = (torch.sigmoid(logits) > threshold).float()
    intersection = (preds * target).sum(dim=(1, 2, 3))
    union = preds.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3))
    dice = (2 * intersection + eps) / (union + eps)
    return dice.mean().item()


def iou_score(logits, target, threshold=0.5, eps=1e-7):
    preds = (torch.sigmoid(logits) > threshold).float()
    intersection = (preds * target).sum(dim=(1, 2, 3))
    union = preds.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3)) - intersection
    iou = (intersection + eps) / (union + eps)
    return iou.mean().item()


def mask_dice(pred, gt, eps=1e-7):
    """Dice between two NumPy binary masks (used for the Otsu comparison)."""
    pred = np.asarray(pred, dtype=bool)
    gt = np.asarray(gt, dtype=bool)
    return float((2 * (pred & gt).sum() + eps) / (pred.sum() + gt.sum() + eps))


def mask_iou(pred, gt, eps=1e-7):
    pred = np.asarray(pred, dtype=bool)
    gt = np.asarray(gt, dtype=bool)
    inter = (pred & gt).sum()
    return float((inter + eps) / (pred.sum() + gt.sum() - inter + eps))


# --------------------------------------------------------------------------
# Torch Dataset over the real nuclei images
# --------------------------------------------------------------------------

class NucleiDataset(Dataset):
    """(image, mask) pairs from one split, cached in memory at UNET_SIZE."""

    def __init__(self, split, size=UNET_SIZE, augment=False):
        self.items = list_split(split)
        self.size = size
        self.augment = augment
        self.images, self.masks, self.ids = [], [], []
        for image_id, ip, mp in self.items:
            img = load_gray(ip, size=size, normalise=True)
            msk = load_mask(mp, size=size)
            self.images.append(img)
            self.masks.append(msk)
            self.ids.append(image_id)

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img = self.images[idx].copy()
        msk = self.masks[idx].copy()
        if self.augment:
            if np.random.rand() < 0.5:
                img, msk = np.fliplr(img).copy(), np.fliplr(msk).copy()
            if np.random.rand() < 0.5:
                img, msk = np.flipud(img).copy(), np.flipud(msk).copy()
            k = np.random.randint(4)
            img, msk = np.rot90(img, k).copy(), np.rot90(msk, k).copy()
        return torch.from_numpy(img).unsqueeze(0), torch.from_numpy(msk).unsqueeze(0)


# --------------------------------------------------------------------------
# Task 4 — inference helper (Lab 4 Exercise 4 contract)
# --------------------------------------------------------------------------

@torch.no_grad()
def segment_image(model, image, size=UNET_SIZE, threshold=0.5, device=None,
                  return_prob=False, out_size=None):
    """Segment one grayscale image with a trained U-Net.

    Always returns a uint8 {0,1} mask of shape (out_size, out_size) — defaulting
    to the network's own input size — even for degenerate input. `out_size`
    lets Task 4 get the mask back at 256 so that regionprops areas are in the
    same pixel units as the ground-truth metadata.
    """
    out_size = size if out_size is None else out_size
    empty = np.zeros((out_size, out_size), np.uint8)
    if device is None:
        device = next(model.parameters()).device

    if isinstance(image, torch.Tensor):
        image = image.detach().cpu().numpy()
    arr = np.asarray(image)

    if arr.ndim == 0 or arr.size == 0:
        return (empty, np.zeros((out_size, out_size), np.float32)) if return_prob else empty

    if arr.ndim == 1:
        arr = arr[None, :]
    elif arr.ndim == 3:
        if arr.shape[-1] in (3, 4):
            arr = rgb2gray(arr[..., :3])
        elif arr.shape[0] in (1, 3, 4):
            arr = arr[:3].mean(axis=0)
        else:
            arr = arr.max(axis=0)
    elif arr.ndim > 3:
        arr = arr.reshape(-1, *arr.shape[-2:]).max(axis=0)

    arr = np.nan_to_num(np.asarray(arr, dtype=np.float32),
                        nan=0.0, posinf=0.0, neginf=0.0)
    if arr.shape != (size, size):
        arr = resize(arr, (size, size), anti_aliasing=True,
                     preserve_range=True).astype(np.float32)
    arr = to_unit_range(arr)

    was_training = model.training
    model.eval()
    prob = torch.sigmoid(model(torch.from_numpy(arr)[None, None].to(device)))
    model.train(was_training)
    prob = prob[0, 0].cpu().numpy()

    if out_size != size:
        prob = resize(prob, (out_size, out_size), order=0,
                      anti_aliasing=False, preserve_range=True)
    mask = (prob > threshold).astype(np.uint8)
    return (mask, prob) if return_prob else mask


# --------------------------------------------------------------------------
# Feature-to-text (Lab 5) — deterministic, so every number the LLM can quote
# has already been measured.
# --------------------------------------------------------------------------

def summarise_features(df, image_name="image"):
    n = len(df)
    if n == 0:
        return (f"In {image_name}, no objects were detected by the "
                f"segmentation pipeline.")
    area, ecc = df["area"], df["eccentricity"]
    sol, inten = df["solidity"], df["mean_intensity"]
    return (
        f"In {image_name}, the segmentation pipeline detected {n} objects. "
        f"Object areas range from {area.min():.0f} to {area.max():.0f} pixels "
        f"(mean {area.mean():.0f}, median {area.median():.0f}). "
        f"Mean eccentricity is {ecc.mean():.2f}; mean solidity is {sol.mean():.2f}. "
        f"Mean object intensity is {inten.mean():.2f}."
    )
