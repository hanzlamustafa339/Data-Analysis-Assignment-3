"""
Task 2 — classical features and the numbers-first LLM description.

Otsu + morphology + connected components + regionprops on the *image* (no
learning anywhere), then the resulting table is compressed to one factual
sentence and handed to a text-only LLM. The model never sees the image, so
anything it says that is not in that sentence is a hallucination by
construction — which is the whole point of the comparison with Task 1.

Outputs
    figures/fig3_otsu_stages.png    smoothing -> threshold -> cleanup -> labels
    metrics/otsu_vs_truth.csv       per-image Otsu accuracy vs ground truth
    records/task2_features.csv      the per-object feature table for one image
    records/task2_llm.json          prompt, raw reply, parsed record, narrative
"""

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from skimage import filters as skfilters
from skimage import measure as skmeasure
from skimage import morphology as skmorphology
from skimage.morphology import disk

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core import (DATA_DIR, FIG_DIR, METRIC_DIR, RECORD_DIR, list_split,
                  load_gray, load_mask, load_metadata, mask_dice, mask_iou,
                  otsu_mask, region_table, summarise_features)
from llm import PROMPT_T2_NUMBERS, chat_local, parse_hybrid_response

DEMO_ID = "train_001"   # a 'normal' density image, used for the worked example


def figure_stages(image_id=DEMO_ID, split="train"):
    """Show every stage so the reader can see where objects are created/lost."""
    img = load_gray(DATA_DIR / split / "images" / f"{image_id}.png")
    gt = load_mask(DATA_DIR / split / "masks" / f"{image_id}.png").astype(bool)

    smooth = skfilters.gaussian(img, sigma=1.0)
    T = skfilters.threshold_otsu(smooth)
    raw = smooth >= T
    cleaned = skmorphology.remove_small_objects(
        skmorphology.closing(skmorphology.opening(raw, disk(1)), disk(2)),
        min_size=30)
    labels = skmeasure.label(cleaned)

    panels = [
        (img, f"grayscale input\n(mean {img.mean():.3f})", "gray"),
        (smooth, "Gaussian smoothed (sigma=1)", "gray"),
        (raw, f"Otsu threshold T={T:.3f}\n{raw.sum()} fg px", "gray"),
        (cleaned, f"opening -> closing -> despeckle\n{cleaned.sum()} fg px", "gray"),
        (labels, f"connected components\n{labels.max()} objects", "nipy_spectral"),
        (gt, f"ground truth\n{skmeasure.label(gt).max()} objects", "gray"),
    ]
    fig, axes = plt.subplots(1, 6, figsize=(20, 3.6))
    for ax, (im, title, cmap) in zip(axes, panels):
        ax.imshow(im, cmap=cmap)
        ax.set_title(title, fontsize=9)
        ax.axis("off")
    fig.suptitle(f"Task 2 — classical pipeline stages on {image_id}", fontsize=12)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig3_otsu_stages.png", dpi=160, bbox_inches="tight")
    plt.close(fig)
    return T


def otsu_accuracy():
    """How well does Otsu alone recover the ground-truth mask and object count?"""
    meta = load_metadata().set_index("image_id")
    rows = []
    for split in ["val", "test"]:
        for iid, ip, mp in list_split(split):
            img = load_gray(ip)
            gt = load_mask(mp).astype(bool)
            pred = otsu_mask(img)
            df = region_table(img, pred)
            rows.append({
                "image_id": iid,
                "split": split,
                "density": meta.loc[iid, "density"],
                "gt_objects": int(meta.loc[iid, "n_objects"]),
                "otsu_objects": len(df),
                "otsu_dice": round(mask_dice(pred, gt), 4),
                "otsu_iou": round(mask_iou(pred, gt), 4),
                "otsu_mean_area": round(float(df["area"].mean()) if len(df) else 0.0, 1),
            })
    out = pd.DataFrame(rows)
    out["count_error"] = out.otsu_objects - out.gt_objects
    out.to_csv(METRIC_DIR / "otsu_vs_truth.csv", index=False)

    print("Otsu vs ground truth")
    print(out.groupby("density")[["otsu_dice", "otsu_iou", "count_error"]]
          .mean().round(3).to_string())
    print(f"\noverall  Dice={out.otsu_dice.mean():.4f}  "
          f"IoU={out.otsu_iou.mean():.4f}  "
          f"mean count error={out.count_error.mean():+.1f}")
    return out


def numbers_first_description(image_id=DEMO_ID, split="train", model="llama3.2"):
    img = load_gray(DATA_DIR / split / "images" / f"{image_id}.png")
    mask = otsu_mask(img)
    df = region_table(img, mask)
    df.to_csv(RECORD_DIR / "task2_features.csv", index=False)

    summary = summarise_features(df, image_name=image_id)
    prompt = PROMPT_T2_NUMBERS.format(summary=summary)
    raw, src = chat_local(prompt, model=model, temperature=0.0)
    record, narrative = parse_hybrid_response(raw)

    meta = load_metadata().set_index("image_id")
    out = {
        "image_id": image_id,
        "model": model,
        "llm_source": src,
        "prompt": prompt,
        "feature_table_shape": list(df.shape),
        "summary_sent_to_model": summary,
        "raw_response": raw,
        "record": record,
        "narrative": narrative,
        "audit": {
            "n_objects_measured": len(df),
            "n_objects_reported_by_llm": record.get("n_objects"),
            "n_objects_ground_truth": int(meta.loc[image_id, "n_objects"]),
            "count_matches_measurement":
                record.get("n_objects") == len(df),
        },
    }
    (RECORD_DIR / "task2_llm.json").write_text(json.dumps(out, indent=2))

    print(f"\nFeature table: {df.shape[0]} objects x {df.shape[1]} features")
    print(df.head(3).to_string(index=False))
    print(f"\nSummary sent to model:\n  {summary}")
    print(f"\nParsed record ({src}): {record}")
    print(f"Audit — measured {len(df)}, LLM said {record.get('n_objects')}, "
          f"ground truth {int(meta.loc[image_id, 'n_objects'])}")
    return out


if __name__ == "__main__":
    figure_stages()
    otsu_accuracy()
    numbers_first_description()
    print("\nTask 2 complete.")
