"""
Task 4 — the hybrid pipeline on the unseen test images, plus the robustness
extension.

Chain:  image -> U-Net mask -> regionprops table -> summary sentence ->
        LLM (structured JSON + narrative) -> aggregated DataFrame -> CSV

Two things are deliberately bolted on, both taken from Lab 5:

*   a **quality gate** that runs on the measurements, before the LLM is called.
    Cheap deterministic checks reject an image without spending an LLM call, so
    a mask full of speckle never reaches the stage that would narrate it.
*   an **audit column** (`n_objects_measured`) copied straight from regionprops.
    If it ever disagrees with the LLM's `n_objects`, the LLM has hallucinated
    and the row is flagged automatically.

Outputs
    records/task4_records.csv       one row per test image (the deliverable)
    records/task4_raw.json          full prompts, raw replies and narratives
    records/task4_report.md         human-readable report
    metrics/robustness_trace.csv    corruption traced stage by stage
    figures/fig7_robustness.png     clean vs blurred vs low-contrast
"""

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core import (DATA_DIR, DEVICE, FIG_DIR, METRIC_DIR, MODEL_DIR, RECORD_DIR,
                  UNet, list_split, load_gray, load_mask, load_metadata,
                  mask_dice, otsu_mask, region_table, segment_image,
                  summarise_features)
from llm import PROMPT_T4_HYBRID, chat_local, parse_hybrid_response


def load_main_model():
    model = UNet(base=16).to(DEVICE)
    model.load_state_dict(torch.load(MODEL_DIR / "unet_main.pth",
                                     map_location=DEVICE))
    model.eval()
    return model


# --------------------------------------------------------------------------
# Quality gate (Lab 5, Exercise 3) — deterministic, runs before the LLM
# --------------------------------------------------------------------------

def quality_gate(df):
    """Pass/fail from the measurement table alone. Returns (passed, reason).

    Thresholds are set from the training distribution: nuclei in this dataset
    are 5-85 per image with areas of roughly 80-400 px at 256x256, so a mean
    area under 20 px means the mask is speckle and over 150 objects means the
    threshold has fragmented the field.
    """
    n = len(df)
    if n == 0:
        return False, "no objects detected"
    if n > 150:
        return False, "too many objects (likely noise / over-segmentation)"
    if df["area"].mean() < 20:
        return False, "mean object area too small (mask is mostly speckle)"
    if df["area"].mean() > 5000:
        return False, "mean object area implausibly large (mask likely merged)"
    return True, "ok"


# --------------------------------------------------------------------------
# The pipeline
# --------------------------------------------------------------------------

def full_pipeline(model, image, image_id, model_name="llama3.2", gate=True):
    mask = segment_image(model, image, out_size=256)          # stage 1
    df = region_table(image, mask)                            # stage 2

    if gate:
        passed, reason = quality_gate(df)
        if not passed:
            return {
                "image_id": image_id, "n_objects": len(df),
                "mean_area": round(float(df["area"].mean()), 1) if len(df) else 0.0,
                "density_class": "unknown", "quality_flag": "fail",
                "gate_reason": reason, "llm_called": False,
                "llm_source": "n/a", "n_objects_measured": len(df),
                "narrative": "Image rejected at quality gate; not narrated.",
            }, df, mask

    summary = summarise_features(df, image_name=image_id)     # stage 3
    prompt = PROMPT_T4_HYBRID.format(image_id=image_id, summary=summary)
    raw, src = chat_local(prompt, model=model_name, temperature=0.0)  # stage 4
    record, narrative = parse_hybrid_response(raw)            # stage 5

    record["image_id"] = image_id
    record["gate_reason"] = "ok"
    record["llm_called"] = True
    record["llm_source"] = src
    record["n_objects_measured"] = len(df)
    record["mean_area_measured"] = round(float(df["area"].mean()), 1) if len(df) else 0.0
    record["narrative"] = narrative
    record["_prompt"] = prompt
    record["_raw"] = raw
    return record, df, mask


def run_test_split(model, model_name="llama3.2"):
    meta = load_metadata().set_index("image_id")
    records, raws = [], []
    for iid, ip, mp in list_split("test"):
        img = load_gray(ip)
        gt = load_mask(mp).astype(bool)
        rec, df, mask = full_pipeline(model, img, iid, model_name=model_name)

        rec["gt_objects"] = int(meta.loc[iid, "n_objects"])
        rec["density_truth"] = meta.loc[iid, "density"]
        rec["unet_dice_vs_gt"] = round(mask_dice(mask.astype(bool), gt), 4)
        rec["count_hallucinated"] = (rec.get("n_objects") !=
                                     rec.get("n_objects_measured"))
        raws.append({"image_id": iid, "prompt": rec.pop("_prompt", ""),
                     "raw_response": rec.pop("_raw", ""),
                     "narrative": rec.get("narrative", "")})
        records.append(rec)

    df = pd.DataFrame(records)
    cols = ["image_id", "n_objects", "mean_area", "density_class", "quality_flag",
            "n_objects_measured", "mean_area_measured", "gt_objects",
            "density_truth", "unet_dice_vs_gt", "count_hallucinated",
            "gate_reason", "llm_called", "llm_source", "narrative"]
    df = df[[c for c in cols if c in df.columns]]
    df.to_csv(RECORD_DIR / "task4_records.csv", index=False)
    (RECORD_DIR / "task4_raw.json").write_text(json.dumps(raws, indent=2))
    return df, raws


def write_markdown_report(df, raws):
    n_flag = int((df.quality_flag != "ok").sum())
    parts = ["# Hybrid pipeline report — unseen test split\n\n",
             f"**Images:** {len(df)}  |  **Passed:** {len(df)-n_flag}  |  "
             f"**Flagged:** {n_flag}  |  "
             f"**LLM source:** {df.llm_source.iloc[0]}\n\n---\n\n"]
    narratives = {r["image_id"]: r["narrative"] for r in raws}
    for _, row in df.iterrows():
        status = "OK" if row.quality_flag == "ok" else "FLAGGED"
        parts.append(f"## {row.image_id} — {status}\n\n")
        parts.append(f"- measured objects: {row.n_objects_measured} "
                     f"(ground truth {row.gt_objects}, "
                     f"regime {row.density_truth})\n")
        parts.append(f"- U-Net Dice vs ground truth: {row.unet_dice_vs_gt}\n")
        parts.append(f"- LLM count matches measurement: "
                     f"{not row.count_hallucinated}\n\n")
        parts.append(f"{narratives.get(row.image_id, '')}\n\n")
    (RECORD_DIR / "task4_report.md").write_text("".join(parts))


# --------------------------------------------------------------------------
# Extension — robustness
# --------------------------------------------------------------------------

def robustness_trace(model, model_name="llama3.2"):
    """Trace blur and low-contrast corruption through every pipeline stage."""
    corr_dir = DATA_DIR / "test_corrupted" / "images"
    cases = []
    for base in ["test_000", "test_004"]:
        cases.append((base, "clean", DATA_DIR / "test" / "images" / f"{base}.png"))
        cases.append((base, "blur", corr_dir / f"{base}_blur.png"))
        cases.append((base, "lowcontrast", corr_dir / f"{base}_lowcontrast.png"))

    meta = load_metadata().set_index("image_id")
    rows, panels = [], []
    for base, kind, path in cases:
        img = load_gray(path)
        gt = load_mask(DATA_DIR / "test" / "masks" / f"{base}.png").astype(bool)
        mask = segment_image(model, img, out_size=256)
        df = region_table(img, mask)
        passed, reason = quality_gate(df)
        summary = summarise_features(df, image_name=f"{base}_{kind}")
        rec, _, _ = full_pipeline(model, img, f"{base}_{kind}",
                                  model_name=model_name, gate=True)

        rows.append({
            "image_id": base,
            "corruption": kind,
            "stage0_img_std": round(float(img.std()), 4),
            "stage0_img_range": round(float(img.max() - img.min()), 4),
            "stage1_fg_fraction": round(float(mask.mean()), 4),
            "stage1_dice_vs_clean_gt": round(mask_dice(mask.astype(bool), gt), 4),
            "stage2_n_objects": len(df),
            "stage2_mean_area": round(float(df["area"].mean()), 1) if len(df) else 0.0,
            "gt_objects": int(meta.loc[base, "n_objects"]),
            "gate_passed": passed,
            "gate_reason": reason,
            "stage4_quality_flag": rec.get("quality_flag"),
            "stage5_narrative": rec.get("narrative", "")[:160],
        })
        panels.append((f"{base}\n{kind}", img, mask, len(df)))

    out = pd.DataFrame(rows)
    out.to_csv(METRIC_DIR / "robustness_trace.csv", index=False)

    fig, axes = plt.subplots(2, 6, figsize=(19, 6.4))
    for c, (title, img, mask, n) in enumerate(panels):
        r, cc = divmod(c, 3)
        axes[r, cc * 2].imshow(img, cmap="gray", vmin=0, vmax=float(max(img.max(), 1e-6)))
        axes[r, cc * 2].set_title(title, fontsize=9)
        axes[r, cc * 2 + 1].imshow(mask, cmap="gray")
        axes[r, cc * 2 + 1].set_title(f"U-Net mask — {n} objects", fontsize=9)
        axes[r, cc * 2].axis("off")
        axes[r, cc * 2 + 1].axis("off")
    fig.suptitle("Extension — how blur and low contrast propagate through the pipeline",
                 fontsize=12)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig7_robustness.png", dpi=160, bbox_inches="tight")
    plt.close(fig)
    return out


if __name__ == "__main__":
    model = load_main_model()
    df, raws = run_test_split(model)
    write_markdown_report(df, raws)
    print("Task 4 — aggregated records (unseen test split)")
    print(df[["image_id", "n_objects_measured", "n_objects", "gt_objects",
              "density_class", "quality_flag", "unet_dice_vs_gt",
              "count_hallucinated"]].to_string(index=False))
    print(f"\nHallucinated counts: {int(df.count_hallucinated.sum())}/{len(df)}")
    print(f"Mean U-Net Dice on test: {df.unet_dice_vs_gt.mean():.4f}")

    trace = robustness_trace(model)
    print("\nRobustness trace")
    print(trace[["image_id", "corruption", "stage0_img_std",
                 "stage1_fg_fraction", "stage1_dice_vs_clean_gt",
                 "stage2_n_objects", "gt_objects", "gate_passed",
                 "stage4_quality_flag"]].to_string(index=False))
    print("\nTask 4 complete.")
